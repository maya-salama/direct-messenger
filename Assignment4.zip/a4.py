# Maya Salama
# salamam2@uci.edu
# 74793795

"""Main module for the ICS 32 Direct Messaging GUI application"""

import tkinter as tk
from tkinter import ttk, filedialog
from Profile import Profile
from ds_messenger import DirectMessenger


class Body(tk.Frame):
    """Frame containing the contact list and message display"""
    def __init__(self, root, recipient_selected_callback=None):
        tk.Frame.__init__(self, root)
        self.root = root
        self._contacts = [str]
        self._select_callback = recipient_selected_callback
        # After all initialization is complete,
        # call the _draw method to pack the widgets
        # into the Body instance
        self._draw()

    def node_select(self, _event):
        """Handle contact selection in the treeview"""
        index = int(self.posts_tree.selection()[0])
        entry = self._contacts[index]
        if self._select_callback is not None:
            self._select_callback(entry)

    def insert_contact(self, contact: str):
        """Add a contact to the list and treeview"""
        self._contacts.append(contact)
        contact_id = len(self._contacts) - 1
        self._insert_contact_tree(contact_id, contact)

    def _insert_contact_tree(self, contact_id, contact: str):
        """Insert a contact entry into the treeview"""
        if len(contact) > 25:
            contact = contact[:24] + "..."
        contact_id = self.posts_tree.insert('', contact_id,
                                            contact_id, text=contact)

    def insert_user_message(self, message: str):
        """Display a sent message right-aligned"""
        self.entry_editor.insert(1.0, message + '\n', 'entry-right')

    def insert_contact_message(self, message: str):
        """Dsiplay a received message left-aligned"""
        self.entry_editor.insert(1.0, message + '\n', 'entry-left')

    def get_text_entry(self) -> str:
        """Return the current text in the message input box"""
        return self.message_editor.get('1.0', 'end').rstrip()

    def set_text_entry(self, text: str):
        """Set the text in the message input box"""
        self.message_editor.delete(1.0, tk.END)
        self.message_editor.insert(1.0, text)

    def _draw(self):
        """Build and pack all widgets"""
        posts_frame = tk.Frame(master=self, width=250)
        posts_frame.pack(fill=tk.BOTH, side=tk.LEFT)

        self.posts_tree = ttk.Treeview(posts_frame)
        self.posts_tree.bind("<<TreeviewSelect>>", self.node_select)
        self.posts_tree.pack(fill=tk.BOTH, side=tk.TOP,
                             expand=True, padx=5, pady=5)

        entry_frame = tk.Frame(master=self)
        entry_frame.pack(fill=tk.BOTH, side=tk.TOP, expand=True)

        editor_frame = tk.Frame(master=entry_frame)
        editor_frame.pack(fill=tk.BOTH, side=tk.LEFT, expand=True)

        scroll_frame = tk.Frame(master=entry_frame, width=10)
        scroll_frame.pack(fill=tk.BOTH, side=tk.LEFT, expand=False)

        message_frame = tk.Frame(master=self)
        message_frame.pack(fill=tk.BOTH, side=tk.TOP, expand=False)

        self.message_editor = tk.Text(message_frame, width=0, height=5)
        self.message_editor.pack(fill=tk.BOTH, side=tk.LEFT,
                                 expand=True, padx=0, pady=0)

        self.entry_editor = tk.Text(editor_frame, width=0, height=5)
        self.entry_editor.tag_configure('entry-right', justify='right')
        self.entry_editor.tag_configure('entry-left', justify='left')
        self.entry_editor.pack(fill=tk.BOTH, side=tk.LEFT,
                               expand=True, padx=0, pady=0)

        entry_editor_scrollbar = tk.Scrollbar(master=scroll_frame,
                                              command=self.entry_editor.yview)
        self.entry_editor['yscrollcommand'] = entry_editor_scrollbar.set
        entry_editor_scrollbar.pack(fill=tk.Y, side=tk.LEFT,
                                    expand=False, padx=0, pady=0)


class Footer(tk.Frame):
    """Frame containing the send button and status label"""
    def __init__(self, root, send_callback=None):
        tk.Frame.__init__(self, root)
        self.root = root
        self._send_callback = send_callback
        self._draw()

    def send_click(self):
        """Handle send button click"""
        if self._send_callback is not None:
            self._send_callback()

    def _draw(self):
        """Build and pack footer widgets"""
        save_button = tk.Button(master=self, text="Send",
                                width=20, command=self.send_click)
        # You must implement this.
        # Here you must configure the button to bind its click to
        # the send_click() function.
        save_button.pack(fill=tk.BOTH, side=tk.RIGHT, padx=5, pady=5)

        self.footer_label = tk.Label(master=self, text="Ready.")
        self.footer_label.pack(fill=tk.BOTH, side=tk.LEFT, padx=5)


class NewContactDialog(tk.simpledialog.Dialog):
    """Dialogue for configuring DS server account settings"""
    def __init__(self, root, title=None, user=None, pwd=None, server=None):
        self.root = root
        self.server = server
        self.user = user
        self.pwd = pwd
        super().__init__(root, title)

    def body(self, frame):
        self.server_label = tk.Label(frame, width=30, text="DS Server Address")
        self.server_label.pack()
        self.server_entry = tk.Entry(frame, width=30)
        self.server_entry.insert(tk.END, self.server)
        self.server_entry.pack()

        self.username_label = tk.Label(frame, width=30, text="Username")
        self.username_label.pack()
        self.username_entry = tk.Entry(frame, width=30)
        self.username_entry.insert(tk.END, self.user)
        self.username_entry.pack()

        self.password_label = tk.Label(frame, width=30, text="Password")
        self.password_label.pack()
        self.password_entry = tk.Entry(frame, width=30)
        self.password_entry.insert(tk.END, self.pwd)
        self.password_entry.pack()
        self.password_entry["show"] = "*"

        # You need to implement also the region for the user to enter
        # the Password. The code is similar to the Username you see above
        # but you will want to add self.password_entry['show'] = '*'
        # such that when the user types, the only thing that appears are
        # * symbols.
        # self.password...

    def apply(self):
        self.user = self.username_entry.get()
        self.pwd = self.password_entry.get()
        self.server = self.server_entry.get()


class MainApp(tk.Frame):
    """Main application frame for the DS direct messaging GUI"""
    def __init__(self, root):
        tk.Frame.__init__(self, root)
        self.root = root
        self.username = ''
        self.password = ''
        self.server = ''
        self.recipient = ''
        # You must implement this! You must configure and
        # instantiate your DirectMessenger instance after this line.
        self.direct_messenger = None
        self.profile = Profile()
        self.dsu_path = None

        # After all initialization is complete,
        # call the _draw method to pack the widgets
        # into the root frame
        self._draw()
        self.body.insert_contact("studentexw23")  # adding one example student.

    def send_message(self):
        """Send a message to the selected recipient"""
        message = self.body.get_text_entry()
        if message and self.recipient and self.direct_messenger:
            self.direct_messenger.send(message, self.recipient)
            self.body.insert_user_message(message)
            self.body.set_text_entry('')
            if self.recipient not in self.profile.messages:
                self.profile.messages[self.recipient] = []
            self.profile.messages[self.recipient].append(
                {"message": message, "recipient": self.recipient}
            )
            if self.dsu_path:
                self.profile.save_profile(self.dsu_path)

    def add_contact(self):
        """Add a new contact to the list"""
        contact = tk.simpledialog.askstring("Add Contact", "Enter username:")
        if contact is not None:
            self.body.insert_contact(contact)
            self.profile.friends.append(contact)
            if self.dsu_path:
                self.profile.save_profile(self.dsu_path)

    def recipient_selected(self, recipient):
        """Handle recipient selection and display their messages"""
        self.recipient = recipient
        self.body.entry_editor.delete(1.0, tk.END)
        for msg in self.profile.messages.get(recipient, []):
            if "from" in msg:
                self.body.insert_contact_message(msg["message"])
            else:
                self.body.insert_user_message(msg["message"])

    def configure_server(self):
        """Configure DS Server settings and intantiate DirectMessenger"""
        ud = NewContactDialog(self.root, "Configure Account",
                              self.username, self.password, self.server)
        self.username = ud.user
        self.password = ud.pwd
        self.server = ud.server
        # You must implement this!
        # You must configure and instantiate your
        # DirectMessenger instance after this line.
        self.direct_messenger = DirectMessenger(self.server,
                                                self.username,
                                                self.password)

    def new_profile(self):
        """Create a new DSU profile file"""
        file_path = filedialog.asksaveasfilename(
            parent=self.root,
            filetypes=[("DSU Files", "*.dsu")],
            defaultextension=".dsu"
        )
        if file_path:
            self.dsu_path = file_path
            with open(file_path, "w", encoding="utf-8"):
                pass
            self.profile.save_profile(file_path)

    def open_profile(self):
        """Open an existing DSU profile file"""
        file_path = filedialog.askopenfilename(
            filetypes=[("DSU Files", "*.dsu")]
        )
        if file_path:
            self.dsu_path = file_path
            self.profile.load_profile(file_path)
            for friend in self.profile.friends:
                self.body.insert_contact(friend)

    def check_new(self):
        """Retrieve and display new messages automatically"""
        if self.direct_messenger is not None:
            new_messages = self.direct_messenger.retrieve_new()
            for msg in new_messages:
                sender = msg.recipient
                if sender not in self.profile.messages:
                    self.profile.messages[sender] = []
                self.profile.messages[sender].append(
                    {"message": msg.message, "from": sender, 
                     "timestamp": msg.timestamp}
                )
                if sender not in self.body._contacts:
                    self.body.insert_contact(sender)
                if sender not in self.profile.friends:
                    self.profile.friends.append(sender)
                if sender == self.recipient:
                    self.body.insert_contact_message(msg.message)
            if new_messages and self.dsu_path:
                self.profile.save_profile(self.dsu_path)
        self.root.after(2000, self.check_new)

    def _draw(self):
        """Build and pack all main application widgets"""
        # Build a menu and add it to the root frame.
        menu_bar = tk.Menu(self.root)
        self.root['menu'] = menu_bar
        menu_file = tk.Menu(menu_bar)

        menu_bar.add_cascade(menu=menu_file, label='File')
        menu_file.add_command(label='New', command=self.new_profile)
        menu_file.add_command(label='Open...', command=self.open_profile)
        menu_file.add_command(label='Close', command=self.root.quit)

        settings_file = tk.Menu(menu_bar)
        menu_bar.add_cascade(menu=settings_file, label='Settings')
        settings_file.add_command(label='Add Contact',
                                  command=self.add_contact)
        settings_file.add_command(label='Configure DS Server',
                                  command=self.configure_server)

        # The Body and Footer classes must be initialized and
        # packed into the root window.
        self.body = Body(self.root,
                         recipient_selected_callback=self.recipient_selected)
        self.body.pack(fill=tk.BOTH, side=tk.TOP, expand=True)
        self.footer = Footer(self.root, send_callback=self.send_message)
        self.footer.pack(fill=tk.BOTH, side=tk.BOTTOM)


if __name__ == "__main__":
    # All Tkinter programs start with a root window. We will name ours 'main'.
    main = tk.Tk()

    # 'title' assigns a text value to the Title Bar area of a window.
    main.title("ICS 32 Distributed Social Messenger")

    # This is just an arbitrary starting point. You can change the value
    # around to see how the starting size of the window changes.
    main.geometry("720x480")

    # adding this option removes some legacy behavior with menus that
    # some modern OSes don't support. If you're curious, feel free to comment
    # out and see how the menu changes.
    main.option_add('*tearOff', False)

    # Initialize the MainApp class, which is the starting point for the
    # widgets used in the program. All of the classes that we use,
    # subclass Tk.Frame, since our root frame is main, we initialize
    # the class with it.
    app = MainApp(main)

    # When update is called, we finalize the states of all widgets that
    # have been configured within the root frame. Here, update ensures that
    # we get an accurate width and height reading based on the types of widgets
    # we have used. minsize prevents the root window from resizing too small.
    # Feel free to comment it out and see how the resizing
    # behavior of the window changes.
    main.update()
    main.minsize(main.winfo_width(), main.winfo_height())
    after_id = main.after(2000, app.check_new)
    print(after_id)
    # And finally, start up the event loop for the program (you can find
    # more on this in lectures of week 9 and 10).
    main.mainloop()
